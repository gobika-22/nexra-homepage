import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome to Gobika's Nexra Homepage! 🚀</h1>
      <p>This is a simple React app deployed with Vercel.</p>
    </div>
  );
}

export default App;